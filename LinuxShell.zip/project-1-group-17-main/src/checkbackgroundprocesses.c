#include "../include/requiredlibraries.h"
#include "../include/globals.h"

#include "../include/changedirectory.h"
#include "../include/checkjobs.h"
#include "../include/envvarcheck.h"
#include "../include/externalexecution.h"
#include "../include/freememory.h"
#include "../include/pathsearch.h"
#include "../include/piping.h"
#include "../include/redirection.h"
#include "../include/requiredlibraries.h"
#include "../include/showhistory.h"
#include "../include/tildeexpansion.h"
#include "../include/tokenization.h"
#include "../include/updatehistory.h"
#include "../include/globals.h"


//check if any processes in background are terminated
void checkBackgroundProcesses() 
{
    pid_t terminatedProcess;
    int status;

    terminatedProcess = waitpid(-1, &status, WNOHANG);

    while (terminatedProcess > 0) 
    {
        for (int i = 0; i < 10; i++) 
        {
            if (backgroundJobs[i].active && backgroundJobs[i].pid == terminatedProcess) 
            {
                printf("[%d] + done %s\n", backgroundJobs[i].jobNumber, backgroundJobs[i].commandLine);
                backgroundJobs[i].active = false; // Set the job as inactive
                break;
            }
        }
        terminatedProcess = waitpid(-1, &status, WNOHANG);
    }
}