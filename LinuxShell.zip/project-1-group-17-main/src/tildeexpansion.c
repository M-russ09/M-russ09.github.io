#include "../include/tildeexpansion.h"

char* tildeExpansion(char *token)
{
    char *home = getenv("HOME");
    
    if (strncmp(token, "~/", 2) == 0)
    {
        memmove(token, token + 1, strlen(token));       //Get rid of tilde ~
        char *toRet = malloc(strlen(home) + strlen(token) + 1);     //allocate new return path
        strcpy(toRet, home);            //copy the home to new allocation
        strcat(toRet, token);           //concatenate the token to the home 
        return toRet;                       
    }
    else if (strcmp(token, "~") == 0)
    {
       return home;         
    } else {
        return token;       //In case '~' or '~/' were not used
    }
}