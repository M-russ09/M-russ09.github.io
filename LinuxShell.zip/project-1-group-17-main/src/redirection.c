#include "../include/redirection.h"

void Redirection(char **command, int infd, int outfd) 
{
    // Check for input and output redirection
        for (int i = 0; command[i] != NULL; i++) 
        {
            if (strcmp(command[i], "<") == 0) // if this symbol then redirect input
            {
                close(infd); //close standard input
                int in_fd = open(command[i + 1], O_RDONLY); //open input
                if (in_fd < 0) 
                {
                    perror("Error opening input file"); //if fails to open
                    exit(EXIT_FAILURE);
                }
                dup2(in_fd, STDIN_FILENO);
                close(in_fd); // Close the file descriptor after redirection
                command[i] = NULL; // Remove '<' from the command
            } 
            else if (strcmp(command[i], ">") == 0) 
            {
                close(outfd); //close standard output
                int out_fd = open(command[i + 1], O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);  //changes output and overwrites existing file
                if (out_fd < 0) 
                {
                    perror("Error opening output file"); //error if fail to open
                    exit(EXIT_FAILURE);
                }
                dup2(out_fd, STDOUT_FILENO);
                close(out_fd); // Close the file descriptor after redirection
                command[i] = NULL; // Remove '>' from the command
            }
        }
}