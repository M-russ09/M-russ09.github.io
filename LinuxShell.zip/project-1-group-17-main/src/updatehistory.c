#include "../include/requiredlibraries.h"
#include "../include/globals.h"


void updateHistory(char **input, CommandHistory history[])   
{
    // Shift existing history entries
    for (int i = 2; i >= 0; i--) {
        strcpy(history[i + 1].commandLine, history[i].commandLine);
        history[i + 1].isValid = history[i].isValid;
    }

    // Store the current command in history[0]
    strcpy(history[0].commandLine, input[0]); // Assuming input[0] is the command itself

    // Check if the current command is valid
    history[0].isValid = (access(input[0], X_OK) == 0);

    if (strcmp(input[0], "jobs")==0 || strcmp(input[0], "cd")==0)
    {
        history[0].isValid= true;
    }
}