#include "../include/externalexecution.h"
#include "../include/redirection.h"

void externalExecution(char **command) 
{
    int status;
    char **cmdCopyin = malloc((MAX_INPUT_SIZE + 1) * sizeof(char *)); //allocate memory
    int infd = dup(STDIN_FILENO);
    int outfd = dup(STDOUT_FILENO); //store standard in and out

    pid_t pid = fork(); //create child process to execute

    if (pid == 0) 
    { // child process
        Redirection(command, infd, outfd); // change redirection if necessary

        // Copy the remaining command into cmdCopyin
        int i = 0;
        while (command[i] != NULL) 
        {
            cmdCopyin[i] = strdup(command[i]);
            i++;
        }
        cmdCopyin[i] = NULL;

        execv(cmdCopyin[0], cmdCopyin); //execute command

        printf("HEREOWWW\n");

        perror("execv failed");
        exit(EXIT_FAILURE);

    } 
    else 
    { // parent process
        waitpid(pid, &status, 0);

        dup2(outfd, STDOUT_FILENO);
        close(outfd);
        dup2(infd, STDIN_FILENO);  //restore standard input and output 
        close(infd);

    }

    dup2(outfd, STDOUT_FILENO);
    dup2(infd, STDIN_FILENO);  //restore standard input and output
}