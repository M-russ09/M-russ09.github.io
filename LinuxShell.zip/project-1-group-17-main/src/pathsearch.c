#include "../include/pathsearch.h"
#include "../include/externalexecution.h"

void pathSearch(char **command)
{

    char *path = strdup(getenv("PATH")); //allocates memory for path
    char *token = strtok(path, ":"); //tokenizes by :

    int found = 0;
    while(token != NULL && found != 1)
    {
        char * check = malloc(sizeof(char) * (strlen(token) + strlen(command[0])+2)); //allocate memory
        strcpy(check, token); //move token into allocated memory
        strcat(check, "/"); //attach a / after the path
        strcat(check,command[0]); //add the command
        if(access(check, F_OK)==0) //access is a commonly used function to find a file
        { //F_OK is a value to check if it exists. if it does it equals 0
            found++; //ends loop if found 
            free(command[0]); 
            command[0] = strdup(check); //alloocate memory for the new value and stores it in command [0]
        
            externalExecution(command);
            
            
        }
        token = strtok(NULL, ":"); //moves to next path 
        free(check); //deallocate memory
    }

    if (found == 0) //if while loop ends and found is 0 that means it didnt find the command
    {
        printf("%s: Command not found.\n", command[0]); //print message
    }
    free(path);
}