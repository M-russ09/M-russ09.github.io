#include "../include/envvarcheck.h"

char* envVarCheck(char *old)
{
    if(old[0] == '$') //check for environmental variables starting with $
    {
        memmove(old, old + 1, strlen(old)); //Remove '$'
        char *new = getenv(old); //Must be all caps to be accepted
        return new;
    }
    else
    {
        return old;
    }
}