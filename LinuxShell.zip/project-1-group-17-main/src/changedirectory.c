#include "../include/requiredlibraries.h"


//////Internal command CD///////////
void changeDirectory(char **command) 
{
    if (command[1] == NULL)  // for if just cd
    {
        // No argument provided, go to the home directory
        const char *home = getenv("HOME");

        if (chdir(home) != 0) 
        {
            fprintf(stderr, "%s: No such file or directory\n", home);
        }
    } 
    else if (command[2] != NULL)  //if more than oen argument
    {
        printf("cd: Too many arguments\n");
    } 
    else 
    {
        // Argument provided, go to the specified directory
        if (chdir(command[1]) != 0) 
        {
            printf("%s: No such file or directory\n", command[1]);
        }
    }
}