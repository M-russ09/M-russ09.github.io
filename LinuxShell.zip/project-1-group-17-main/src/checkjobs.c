#include "../include/requiredlibraries.h"
#include "../include/globals.h"



void checkJobs(char ** commands)
{
    for (int i = 0; i < 10; i ++)
    {
        if (backgroundJobs[i].active)
        {
            printf("[%d] + %d running       %s\n", backgroundJobs[i].jobNumber, backgroundJobs[i].pid, backgroundJobs[i].commandLine);
        }
    }
}