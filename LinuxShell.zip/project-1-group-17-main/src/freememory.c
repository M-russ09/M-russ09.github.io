#include "../include/requiredlibraries.h"

void freeMemory(char **command) 
{ //frees up memory
    for (int i = 0; command[i] != NULL; i++) 
    {
        free(command[i]); 
    }
    free(command);
}