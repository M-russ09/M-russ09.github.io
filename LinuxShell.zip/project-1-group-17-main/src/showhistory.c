#include "../include/requiredlibraries.h"
#include "../include/globals.h"

void showHistory(CommandHistory history[])  
{
    int validCount = 0;

    // Check the validity of the last three commands
    for (int i = 0; i < 3; i++) 
    {
        if (history[i].isValid) 
        {
            validCount++;
        }
    }

    // Display the last three valid commands or indicate no valid commands
    if (validCount == 3) 
    {
        printf("Last Three Valid Commands:\n"); //if last three all valid then print all
        for (int i = 0; i < 3; i++) {
            printf("Command %d: %s\n", i + 1, history[i].commandLine);
        }
    } else if (validCount > 0) { //prints last valid 
        printf("Last Valid Command:\n");
        for (int i = 0; i < 3; i++) {
            if (history[i].isValid != 0) {
                printf("Command %d: %s\n", i + 1, history[i].commandLine);
            }
        }
    } else {
        printf("No valid commands.\n"); //if no valid print
        
    }
}