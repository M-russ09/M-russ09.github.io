#include "../include/requiredlibraries.h"
#include "../include/pathsearch.h"

///////////Piping function to redirect input and output of commands/////
void Piping(char **command) 
{
    int commandCount = 0;
    char ***commands = malloc(sizeof(char**) * MAX_INPUT_SIZE); 
    //an array of an array of strings
    //each index points to a char** of commands
    //commands[0][0-1] can be ls -al
    //commands[1][0-2] can grep -i main and so on

    int i = 0;
    while (command[i] != NULL) 
    { //loops through the input until it reaches end
        int j = 0;
        commands[commandCount] = malloc(sizeof(char*) * MAX_INPUT_SIZE);

        while (command[i] != NULL && strcmp(command[i], "|") != 0) 
        { //seperates each commandline and each arguments
            commands[commandCount][j] = strdup(command[i]);
            i++;
            j++;
        }

        commands[commandCount][j] = NULL; //sets last of each command line to NULL
        commandCount++; //increments to next array slot to hold next set of command
        if (command[i] != NULL) {
            i++; // Skip the "|"
        }
    }

    int pipes[2 * (commandCount - 1)]; // Create pipes 2 slots for each command line minus one 
                                        //since last doesnt need a pipe for writing

    for (int k = 0; k < commandCount - 1; k++) 
    {
        if (pipe(pipes + 2 * k) < 0) 
        { //an array for all pipe of each command line 
            //seperating the array two indexes each one for read and one for write
            perror("pipe error");
            exit(EXIT_FAILURE);
        }
    }

    for (int k = 0; k < commandCount; k++) { //loops through each command
        pid_t pid = fork();
        if (pid == 0) {
            if (k > 0) 
            {
                dup2(pipes[2 * (k - 1)], STDIN_FILENO); // Redirect input from the previous command 
                //input is the first of 2 slots for each command line. k is used to coordinate which two slots
                //in pipes goes with the commandline
            }
            if (k < commandCount - 1) {
                dup2(pipes[2 * k + 1], STDOUT_FILENO); // Redirect output to the next command
                //sets output to the first input slot of next command line
            }

            // Close all pipe file descriptors in the child process
            for (int j = 0; j < 2 * (commandCount - 1); j++) //commandcount is command 3 but minus 1 since array starts at 0
            { //closes everything through the current command line
                close(pipes[j]);
            }

            pathSearch(commands[k]); // Execute the command

            // If pathSearch fails, exit the child process
            exit(EXIT_SUCCESS);
        } else if (pid < 0) {
            perror("fork error");
            exit(EXIT_FAILURE);
        }
    }

    // Close all pipe file descriptors in the parent process
    for (int k = 0; k < 2 * (commandCount - 1); k++) 
    { //makes sure all is closed 
        close(pipes[k]);
    } 

    // Wait for all child processes to complete
    for (int k = 0; k < commandCount; k++) 
    { //loops based on how many pipes
        wait(NULL); //system call that waits till its child process to exit
    }
    // Free allocated memory
    for (int k = 0; k < commandCount; k++) 
    {
        free(commands[k]);
    }
   
}