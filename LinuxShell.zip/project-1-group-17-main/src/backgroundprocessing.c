#include "../include/backgroundprocessing.h"
#include "../include/changedirectory.h"
#include "../include/checkjobs.h"
#include "../include/envvarcheck.h"
#include "../include/externalexecution.h"
#include "../include/freememory.h"
#include "../include/pathsearch.h"
#include "../include/piping.h"
#include "../include/redirection.h"
#include "../include/requiredlibraries.h"
#include "../include/showhistory.h"
#include "../include/tildeexpansion.h"
#include "../include/tokenization.h"
#include "../include/updatehistory.h"
#include "../include/globals.h"


//puts command in background
void backgroundProcessing(char **command, int lastCommandIndex) {
    pid_t pid = fork();

    if (pid == 0) 
    {
        // Child process
        usleep(100); //small sleep to allow job num to print
        int p = 0;
        for (int i = 0; command[i] != NULL; i++) 
        {
            if (strcmp(command[i], "|") == 0) {
                p++;
                Piping(command);
                
            }
        }

        if (p == 0) 
        {
            pathSearch(command);
            
        }
        exit(EXIT_SUCCESS);

    } 
    else if (pid > 0) 
    {
        // Parent process
        int jobIndex;
        for (int i = 0; i < 10; i++) 
        {
            if (!backgroundJobs[i].active) 
            {
                jobIndex = i;
                break;
            }
        }

        backgroundJobs[jobIndex].pid = pid;
        backgroundJobs[jobIndex].jobNumber = jobIndex + 1;
        backgroundJobs[jobIndex].active = true;

        backgroundJobs[jobIndex].commandLine[0] = '\0'; // Reset command line
        for (int k = 0; k <= lastCommandIndex; k++) 
        {
            strcat(backgroundJobs[jobIndex].commandLine, command[k]);
            if (command[k + 1] != NULL) 
            {
                strcat(backgroundJobs[jobIndex].commandLine, " ");
            }
        }

    printf("[%d] %d %s\n", backgroundJobs[jobIndex].jobNumber, backgroundJobs[jobIndex].pid, backgroundJobs[jobIndex].commandLine);

    usleep(100000);

    
    } 
    else 
    {
        perror("fork error");
        exit(EXIT_FAILURE);
    }
    // Additional code to wait for the completion of the job
        waitpid(pid>0, NULL, WNOHANG);
        fflush(stdout);
}