#include "globals.h"
#include "tokenization.h"
#include "tildeexpansion.h"
#include "externalexecution.h"
#include "envvarcheck.h"
#include "pathsearch.h"
#include "piping.h"
#include "redirection.h"
#include "updatehistory.h"
#include "backgroundprocessing.h"
#include "changedirectory.h"
#include "checkbackgroundprocesses.h"
#include "checkjobs.h"
#include "freememory.h"
#include "requiredlibraries.h"
#include "showhistory.h"
#include "exitshell.h"
#define MAX_INPUT_SIZE 200
#define MAX_JOBS 10
#define MAX_HISTORY 3

int backgroundJobNumber = 1;

BackgroundJob backgroundJobs[MAX_JOBS];
CommandHistory commandHistory[3];
int validCmdCount = 0;

int main() {  //*********TO EXIT FOR NOW KILL PROGRAM BY CLICKING CTRL-C************

char *user = getenv("USER");
char *machine = getenv("MACHINE");

    while (1) 
    { //loop till exit

        int background = 0; // Flag to indicate background execution
        int lastCommandIndex = 0; // Index of the last command in the command array

        char cwd[1024];
        getcwd(cwd, sizeof(cwd));  //constantly updates cwd
        int skip = 0;


        char input[MAX_INPUT_SIZE]; 
        if (!background) 
        {
            // Print the prompt only if not in background
            printf("%s@%s:%s>", user, machine, cwd);
            fflush(stdout);
        }
        if(fgets(input, sizeof(input), stdin) == NULL) 
        {
            break;
        }

        input[strcspn(input, "\n")] = '\0'; //removes newline character

        if (strlen(input) == 0) 
        {
            continue; //Skip to next iterartion of loop
        }
        char **command = Tokenization(input); //tokenizes input AND checks for environ. vars.

        for (int i = 0; command[i] != NULL; i++) 
        {
            if (strcmp(command[i], "&") == 0 && command[i+1] == NULL) 
            {
                background = 1; // Set the background flag
                command[i] = NULL; // Remove "&" from the command
                lastCommandIndex = i - 1; // Set the index of the last command
                backgroundProcessing(command, lastCommandIndex);
                skip++;
                break;
            }
        }

        if (strcmp(command[0], "jobs") == 0 && skip == 0)
        {
            checkJobs(command); //checks for internal command cd
            skip++; //if it cd increment skip so it passes the other executions
        }

        if (strcmp(command[0], "cd") == 0 && skip == 0)
        {
            changeDirectory(command); //checks for internal command cd
            skip++; //if it cd increment skip so it passes the other executions
        }

         if (strcmp(command[0], "exit") == 0 && skip ==0) 
        {
            // Wait for any background processes to finish
            checkBackgroundProcesses();

            // Display the last three valid commands
            showHistory(commandHistory);

            freeMemory(command);

            // Exit the shell
            exitShell();
        } 

        int p=0;
        for (int i = 0; command[i] != NULL && skip == 0; i++) //loops through till null
        {
            if (strcmp(command[i], "|") == 0) //if it has | symbol send it to piping commnad
            {
                p++;
                Piping(command);
                break;
            }
        }
        if(p == 0 && skip == 0) //only do this if it didnt have piping
        { //or if it wasnt a internal command
            pathSearch(command);
        }
        
        checkBackgroundProcesses();
        updateHistory(command, commandHistory);
        freeMemory(command);  //Free the dynamically allocated memory
    }
    

    return 0;
}


//end