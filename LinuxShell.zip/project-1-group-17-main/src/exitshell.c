#include "../include/exitshell.h"

/////////Exit function////////////
void exitShell() {
    // Check for any active background processes
    checkBackgroundProcesses();

    // Wait for all background processes to complete
    for (int i = 0; i < 10; i++) 
    {
        if (backgroundJobs[i].active) 
        {
            printf("Waiting for background processing to finish\n");
            waitpid(backgroundJobs[i].pid, NULL, 0); //waits still all jobs finish
            printf("[%d] + done %s\n", backgroundJobs[i].jobNumber, backgroundJobs[i].commandLine);
            backgroundJobs[i].active = false; // Set the job as inactive
        }
    }

    printf("Exiting shell.\n");
    exit(EXIT_SUCCESS); //exits
}