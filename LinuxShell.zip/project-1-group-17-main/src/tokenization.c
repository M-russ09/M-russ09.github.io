#include "../include/tokenization.h"
#include "../include/tildeexpansion.h"
#include "../include/envvarcheck.h"

char** Tokenization(char input[]) 
{
    char **command = malloc(MAX_INPUT_SIZE * sizeof(char*)); //allocates memory
    int i = 0; //increment

    char *token = strtok(input, " "); //tokenizes by spaces
    while (token != NULL && i < MAX_INPUT_SIZE - 1) {
        token=tildeExpansion(token);
        token=envVarCheck(token); 
        if (token==NULL) //Checks if token environ. var. is valid 
        {
            printf("Undefined variable\n");
            break;
        }
        command[i++] = strdup(token); //grabs next token and stores it
        token = strtok(NULL, " "); 
    }

    command[i] = NULL; //end command with null value
    return realloc(command, (i + 1) * sizeof(char*)); //Resize the array to fit the actual number of tokens
}