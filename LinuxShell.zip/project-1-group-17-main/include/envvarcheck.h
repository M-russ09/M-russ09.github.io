#pragma once
#include "../include/requiredlibraries.h"

char* envVarCheck(char *old);