#pragma once
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdbool.h>

#define MAX_INPUT_SIZE 200  // On site it says assume commands is less than 200 characters
#define MAX_JOBS 10
#define MAX_HISTORY 3