#pragma once
#include "../include/requiredlibraries.h"

void externalExecution(char **command);