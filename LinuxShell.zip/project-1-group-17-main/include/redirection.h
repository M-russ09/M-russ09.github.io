#pragma once
#include "../include/requiredlibraries.h"
#include "../include/backgroundprocessing.h"
#include "../include/changedirectory.h"
#include "../include/checkjobs.h"
#include "../include/envvarcheck.h"
#include "../include/externalexecution.h"
#include "../include/freememory.h"
#include "../include/pathsearch.h"
#include "../include/piping.h"
#include "../include/requiredlibraries.h"
#include "../include/showhistory.h"
#include "../include/tildeexpansion.h"
#include "../include/tokenization.h"
#include "../include/updatehistory.h"
#include "../include/globals.h"

void Redirection(char **command, int infd, int outfd);