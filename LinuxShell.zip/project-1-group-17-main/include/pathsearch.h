#pragma once
#include "../include/requiredlibraries.h"

void pathSearch(char **command);