#pragma once
#include "../include/requiredlibraries.h"

void changeDirectory(char **);