#pragma once
#include "../include/requiredlibraries.h"

char** Tokenization(char input[]);