// globals.h
#pragma once

#include "../include/requiredlibraries.h"

typedef struct {
    char commandLine[MAX_INPUT_SIZE];
    bool isValid;
} CommandHistory;



typedef struct {
    pid_t pid;
    int jobNumber;
    char commandLine[MAX_INPUT_SIZE];
    bool active;
} BackgroundJob;

extern BackgroundJob backgroundJobs[];

extern char *history[];
extern int validCmdCount;





