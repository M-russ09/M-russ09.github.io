#pragma once
#include "../include/requiredlibraries.h"
#include "../include/changedirectory.h"
#include "../include/checkjobs.h"
#include "../include/envvarcheck.h"
#include "../include/externalexecution.h"
#include "../include/freememory.h"
#include "../include/pathsearch.h"
#include "../include/piping.h"
#include "../include/redirection.h"
#include "../include/requiredlibraries.h"
#include "../include/showhistory.h"
#include "../include/tildeexpansion.h"
#include "../include/tokenization.h"
#include "../include/updatehistory.h"
#include "../include/globals.h"

void backgroundProcessing(char **, int );