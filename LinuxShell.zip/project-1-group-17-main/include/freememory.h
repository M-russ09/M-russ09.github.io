#pragma once
#include "../include/requiredlibraries.h"

void freeMemory(char **command);