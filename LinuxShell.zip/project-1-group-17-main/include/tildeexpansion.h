#pragma once
#include "../include/requiredlibraries.h"

char* tildeExpansion(char *token);