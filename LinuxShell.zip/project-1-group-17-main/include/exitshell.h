#pragma once
#include "../include/requiredlibraries.h"
#include "../include/globals.h"
#include "../include/checkbackgroundprocesses.h"

void exitShell();