#pragma once
#include "../include/requiredlibraries.h"

void Piping(char **);