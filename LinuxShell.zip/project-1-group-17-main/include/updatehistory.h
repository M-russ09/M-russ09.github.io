#pragma once
#include "../include/requiredlibraries.h"

void updateHistory(char **, CommandHistory []);