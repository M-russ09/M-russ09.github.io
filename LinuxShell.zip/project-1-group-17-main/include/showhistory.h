#pragma once
#include "../include/requiredlibraries.h"
#include "../include/globals.h"

void showHistory(CommandHistory []);