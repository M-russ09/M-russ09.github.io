# Project 3 FAT32 File System

The purpose of this project is to familiarize you with basic file-system design and implementation. You
will need to understand various aspects of the FAT32 file system, such as cluster-based storage, FAT
tables, sectors, and directory structure.


## Contributing

- Parker Thompson [pjt21@fsu.edu]
- Mason Russo [mer21i@fsu.edu]
- Cesar Marquez [cdm21h@fsu.edu]


## Division of Labor Before Project Completion
Part1: Mount the Image File
- Mason Russo, Parker Thompson, Cesar Marquez 

Part2: Navigation
- Mason Russo, Parker Thompson, Cesar Marquez 

Part3: Create
- Mason Russo, Parker Thompson, Cesar Marquez 

Part4: Read
- Mason Russo, Parker Thompson, Cesar Marquez 

Part5: Update
- Mason Russo, Parker Thompson, Cesar Marquez 

Part6: Delete
- Mason Russo, Parker Thompson, Cesar Marquez 


## Division of Labor After Project Completion
Part1: Mount the Image File
- Parker Thompson

Part2: Navigation
- Parker Thompson

Part3: Create
- Parker Thompson, Mason Russo

Part4: Read
- Parker Thompson, Mason Russo

Part5: Update
-Mason Russo

Part6: Delete
- Parker Thompson


## LICENSE
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

