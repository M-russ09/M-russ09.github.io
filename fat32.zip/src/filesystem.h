#ifndef _FILESYSTEM_H
#define _FILESYSTEM_H

#include <stdio.h>
#include <inttypes.h>
#include <string.h>
#include "list.h"

#define MAX_PATH_LENGTH 4000

//Boot Parameter Sector
typedef struct __attribute__((packed)) {
    char BS_jmpBoot[3];
    char BS_OEMName[8];
    uint16_t BPB_BytsPerSec;
    uint8_t BPB_SecPerClus;
    uint16_t BPB_RsvdSecCnt;
    uint8_t BPB_NumFATs;
    uint32_t BPB_TotSec32;
    uint32_t BPB_FATSz32;
    uint32_t BPB_RootClus;
} BPB_t;

typedef struct __attribute__((packed)) directory_entry {
    char DIR_Name[11];
    uint8_t DIR_Attr;
    char padding_1[8]; // DIR_NTRes, DIR_CrtTimeTenth, DIR_CrtTime, DIR_CrtDate, 
                       // DIR_LstAccDate. Since these fields are not used in
                       // Project 3, just define as a placeholder.
    uint16_t DIR_FstClusHI;
    char padding_2[4]; // DIR_WrtTime, DIR_WrtDate
    uint16_t DIR_FstClusLO;
    uint32_t DIR_FileSize;
} dentry_t;

uint32_t current_cluster; //stores current cluster
struct Node *previous_clusters = NULL; // Stores previous clusters in a linked list
char current_path[MAX_PATH_LENGTH];


typedef struct __attribute__((packed)) {
    char fileName[11];
    int flag; // 1: r, 2: w, 3: rw, 4: wr
    uint32_t currentFilePosition; // Starting cluster of the file
    uint32_t currentFilePositionOffset; // Offset within the image file
    uint32_t offset;
    int index;
    char path[400];
} openedFile;

openedFile openedFiles[10];


int determineMode(const char *mode) {
    if (strcmp(mode, "-r") == 0) return 1; // Read-only
    if (strcmp(mode, "-w") == 0) return 2; // Write-only
    if (strcmp(mode, "-rw") == 0) return 3; // Read and write
    if (strcmp(mode, "-wr") == 0) return 4; // Write and read
    return 0; // Invalid mode
}

#endif