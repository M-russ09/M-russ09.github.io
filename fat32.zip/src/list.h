#ifndef _LIST_H
#define _LIST_H

#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include "list.c"
#include "filesystem.h"

// Function to insert a new node at the beginning of the linked list
void insert(struct Node **head, uint32_t cluster);

// Function to remove the first node from the linked list
void removeFirst(struct Node **head);

// Function to free the memory allocated for the linked list
void freeList(struct Node *head);



#endif