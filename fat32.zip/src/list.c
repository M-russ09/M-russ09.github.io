#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include "filesystem.h"

#define MAX_PATH_LENGTH 256

// Define the structure for a node in the linked list
struct Node 
{
    uint32_t cluster;
    struct Node *next;
};

// Function to insert a new node at the beginning of the linked list
void insert(struct Node **head, uint32_t cluster) 
{
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    if (newNode == NULL) 
    {
        printf("Memory allocation failed\n");
        return;
    }
    newNode->cluster = cluster;
    newNode->next = *head;
    *head = newNode;
}

// Function to remove the first node from the linked list
void removeFirst(struct Node **head) 
{
    if (*head == NULL) 
    {
        printf("Linked list is empty\n");
        return;
    }
    struct Node *temp = *head;
    *head = (*head)->next;
    free(temp);
}

// Function to free the memory allocated for the linked list
void freeList(struct Node *head) 
{
    struct Node *current = head;
    while (current != NULL) 
    {
        struct Node *temp = current;
        current = current->next;
        free(temp);
    }
}



