#include <stdio.h>
#include <inttypes.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h> 
#include "list.h"
#include "filesystem.h"

#define MAX_PATH_LENGTH 256


void readBootSector(BPB_t *, FILE *);
char** Tokenization(char []);
void printInfo(BPB_t bpb);
void listDirectory(FILE *, BPB_t *, uint32_t );
void changeDirectory(FILE *, BPB_t *, const char *);
void makeDirectory(FILE *, BPB_t *bpb, const char *);
void createFile(FILE *, BPB_t *, const char *);
void openFile(FILE *, BPB_t *, const char *, const char *);
void closeFile(const char *);
void listOpenedFiles();
void lseekCommand(FILE *, const char *,BPB_t *, uint32_t );
void removeFile(FILE *, BPB_t *, const char *);
void removeDirectory(FILE *, BPB_t *, const char *);
int isDirectoryEmpty(FILE *, BPB_t *, uint32_t );
void deallocateClusters(FILE *, BPB_t *, uint32_t );
void readFromFile(FILE *, const char *, size_t  );
void writeToFile(FILE *, const char *, char *);
uint32_t findFreeCluster(FILE *, BPB_t *);
uint32_t findFreeDirectoryEntry(FILE *, uint32_t , int );
uint32_t get_next_cluster(FILE *, BPB_t *, uint32_t );
void addToPath(char *);

int openFileCount = 0;
int pathLength=0;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [FAT32 IMG]\n", argv[0]);
        return 1;
    }

    FILE *fp = fopen(argv[1], "rb+");
    if (fp == NULL) {
        fprintf(stderr, "Error: Unable to open the image file.\n", argv[1]);
        return 1;
    }
    BPB_t bpb;
    // Initialize `path` as an array of strings (pointers)
    

    int pathLength=0;

    readBootSector(&bpb, fp);
    current_cluster = bpb.BPB_RootClus;

    addToPath(argv[1]);

    
    while(1)
    {
        char input[100];
        
        printf("%s", current_path);
        
        printf(">");

        if(fgets(input, sizeof(input), stdin) == NULL) 
        {
            break;
        }
        input[strcspn(input, "\n")] = '\0'; //removes newline character

        if (strlen(input) == 0) 
        {
            continue; //Skip to next iterartion of loop
        }

        char **command = Tokenization(input); //tokenizes input

        if (strcmp(command[0], "info") == 0)
        {
            if(command[1] != NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
             printInfo(bpb);
        }
        else if (strcmp(command[0], "ls") == 0)
        {
            if(command[1] != NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            listDirectory(fp, &bpb, current_cluster);
            printf("\n");
        }
        else if (strcmp(command[0], "cd") == 0) 
        {
            if (command[1] == NULL) 
            {
                // No directory specified, move to parent directory
                changeDirectory(fp, &bpb, "..");
            }
            else if (command[2] != NULL) 
            {
                printf("Too many arguments\n");
                continue;
            }
            else 
            {
                changeDirectory(fp, &bpb, command[1]);
            }
        }
        else if (strcmp(command[0], "mkdir") == 0)
        {
            if(command[1] == NULL || command[2] != NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            else
            {
                makeDirectory(fp, &bpb, command[1]);
            }
        }
        else if (strcmp(command[0], "creat") == 0)
        {
            if(command[1] == NULL || command[2] != NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            else
            {
                createFile(fp, &bpb, command[1]);
            }
        }
        else if (strcmp(command[0], "open") == 0)
        {
            if(command[1] == NULL || command[2] == NULL || command[3] !=NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            else
            {
                openFile(fp, &bpb, command[1], command[2]);
            }
        }
        else if (strcmp(command[0], "close") == 0)
        {
            if(command[1] == NULL || command[2] != NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            else
            {
                closeFile(command[1]);
            }
        }
        else if (strcmp(command[0], "lsof") == 0)
        {
            if(command[1] != NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            listOpenedFiles();
            printf("\n");
        }
        else if (strcmp(command[0], "lseek") == 0)
        {
            if(command[1] == NULL || command[2] == NULL || command[3] !=NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            else
            {
                char *endPtr;
                size_t offset = strtoul(command[2], &endPtr, 10);
                lseekCommand(fp, command[1], &bpb, offset);
            }
        }
        else if (strcmp(command[0], "rm") == 0)
        {
            if(command[1] == NULL || command[2] != NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            else
            {
                removeFile(fp, &bpb, command[1]);
            }
        }
        else if (strcmp(command[0], "rmdir") == 0)
        {
            if(command[1] == NULL || command[2] != NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            else
            {
                removeDirectory(fp, &bpb, command[1]);
            }
        }
        else if (strcmp(command[0], "read") == 0)
        {
            if(command[1] == NULL || command[2] == NULL || command[3] !=NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            else
            {
                char *endPtr;
                size_t size = strtoul(command[2], &endPtr, 10);
                readFromFile(fp, command[1], size);
            }
        }
        else if (strcmp(command[0], "write") == 0)
        {
            if(command[1] == NULL || command[2] == NULL || command[3] !=NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            else
            {
                writeToFile(fp, command[1], command[2]);
            }
        }
        else if (strcmp(command[0], "exit") == 0)
        {
            if(command[1] != NULL)
            {
                printf("Incorrect amount of arguments\n");
                continue;
            }
            freeList(previous_clusters);
            break;
        }
        for(int i=0; command[i]< NULL;i++)
        {
            free(command[0]);
        }
    }


    fclose(fp);

    return 0;
}

/*==========================================================================
                                MAIN FUNCTIONS
============================================================================*/


void listDirectory(FILE *imgFile, BPB_t *bpb, uint32_t current_cluster_number) 
{
    // Calculate the offset of the first data sector
    uint32_t firstDataSector = (bpb->BPB_RsvdSecCnt + bpb->BPB_NumFATs * bpb->BPB_FATSz32) * bpb->BPB_BytsPerSec;

    // Iterate through the clusters in the current cluster chain
    while (current_cluster_number < 0x0FFFFFF8) {
        // Calculate the offset of the current cluster
        uint32_t cluster_offset = firstDataSector + (current_cluster_number - 2) * bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;

        // Iterate through each directory entry in the current cluster
        for (uint32_t i = 0; i < bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec; i += sizeof(dentry_t)) 
        {
            dentry_t entry;

            // Seek to the current entry and read it
            fseek(imgFile, cluster_offset + i, SEEK_SET);
            fread(&entry, sizeof(dentry_t), 1, imgFile);

            // Skip empty and deleted entries
            if (entry.DIR_Name[0] == 0x00 || entry.DIR_Name[0] == 0xE5) 
            {
                continue;
            }

            // Skip long file entries
            if (entry.DIR_Attr == 0x0F) 
            {
                continue;
            }

            char name[12];
            memset(name, 0, sizeof(name));
            strncpy(name, entry.DIR_Name, sizeof(entry.DIR_Name));
            name[11] = '\0'; 

            // Trim trailing spaces from the name
            for (int j = 11; j >= 0; j--) {
                if (name[j] == ' ' || name[j] == '\0') {
                    name[j] = '\0';
                }
            }

            // Check the attribute to identify directories
            int is_directory = (entry.DIR_Attr & 0x10) != 0;

            // Print the directory or file name accordingly
            if (is_directory) {
                // Print `.` and `..` as well as other directories
                printf("%s/   ", name);
            } else 
            {
                // Print the file name
                printf("%s   ", name);
            }
        }

        // Move to the next cluster in the chain
        current_cluster_number = get_next_cluster(imgFile, bpb, current_cluster_number);
    }
}



void changeDirectory(FILE *fp, BPB_t *bpb, const char *dirname) 
{
    dentry_t dentry;
    uint32_t firstDataSector = (bpb->BPB_RsvdSecCnt + bpb->BPB_NumFATs * bpb->BPB_FATSz32) * bpb->BPB_BytsPerSec;
    uint32_t currentOffset = firstDataSector + (current_cluster - 2) * bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;
    int found = 0;

    // If the dirname is null or "..", handle navigating up the directory tree
    if (dirname == NULL || strcmp(dirname, "..") == 0) {
        if (pathLength > 0) 
        {
            addToPath(dirname);
            pathLength--;
        }
        if (previous_clusters != NULL) {
            current_cluster = previous_clusters->cluster;
            removeFirst(&previous_clusters);
        }
        return;
    }

    // If the dirname is ".", return without doing anything
    if (strcmp(dirname, ".") == 0) {
        return;
    }
    uint32_t targetCluster = current_cluster;
   
    // Traverse the cluster chain to find the target directory
    while (targetCluster < 0x0FFFFFF8 && !found) {
        currentOffset = firstDataSector + (targetCluster - 2) * bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;

        for (int i = 0; i < bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec; i += sizeof(dentry_t)) {
            fseek(fp, currentOffset + i, SEEK_SET);
            fread(&dentry, sizeof(dentry_t), 1, fp);

            if (dentry.DIR_Name[0] == '\0') {
                continue; // End of entries
            }

            // Check if the entry is a directory
            if (dentry.DIR_Attr == 0x10) {
                char name[12];
                strncpy(name, dentry.DIR_Name, sizeof(dentry.DIR_Name));
                name[11] = '\0';
                
                // Trim trailing spaces
                for (int j = 10; j >= 0; j--) {
                    if (name[j] == ' ' || name[j] == '\0') {
                        name[j] = '\0';
                    }
                }

                // Check if the name matches the target directory
                if (strcmp(name, dirname) == 0) {
                    found = 1;
                    targetCluster = (dentry.DIR_FstClusHI << 16) | dentry.DIR_FstClusLO;
                    break;
                }
            }
        }

        // If target directory not found, move to the next cluster in the chain
        if (!found) {
            targetCluster = get_next_cluster(fp, bpb, targetCluster);
        }
    }

    if (found) {
        // Update the current cluster and navigate down the directory tree
        insert(&previous_clusters, current_cluster);
        current_cluster = targetCluster;
        pathLength++;
        addToPath(dirname);
    } else {
        printf("Directory not found\n");
    }
}



void makeDirectory(FILE *fp, BPB_t *bpb, const char *dirname) 
{
    // Ensure the length of the directory name is within limits
    if (strlen(dirname) > 11) 
    {
        printf("Error: Directory name '%s' is too long (max 11 characters).\n", dirname);
        return;
    }

    // Check if the directory already exists
    dentry_t dentry;
    uint32_t firstDataSector = (bpb->BPB_RsvdSecCnt + bpb->BPB_NumFATs * bpb->BPB_FATSz32) * bpb->BPB_BytsPerSec;
    int clusterSize = bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;
    uint32_t currentOffset = firstDataSector + (current_cluster - 2) * clusterSize;
    fseek(fp, currentOffset, SEEK_SET);

    while (fread(&dentry, sizeof(dentry_t), 1, fp) == 1) 
    {
        if (dentry.DIR_Name[0] == '\0') 
        {
            break; // End of directory entries
        }

        // Trim trailing spaces from the file name
        char trim[12];
        int i;
        for (i = 10; i >= 0; i--) 
        {
            if (!isspace(dentry.DIR_Name[i])) 
            {
                break;
            }
        }
        strncpy(trim, dentry.DIR_Name, i + 1);
        trim[i + 1] = '\0';

        // Check if the file/directory name matches the specified `dirname`
        if (strcmp(trim, dirname) == 0) 
        {
            printf("Error: A file or directory called '%s' already exists.\n", dirname);
            return;
        }
    }

    // Find free directory entry
    uint32_t freeEntryOffset = findFreeDirectoryEntry(fp, currentOffset, clusterSize);
    if (freeEntryOffset == 0) 
    {
        printf("No free directory entries available in the current working directory.\n");
        return;
    }

    // Create the new directory entry
    dentry_t newDir;
    memset(&newDir, 0, sizeof(dentry_t));
    strncpy(newDir.DIR_Name, dirname, 11);
    newDir.DIR_Attr = 0x10; // Directory attribute

    // Find free cluster
    uint32_t newCluster = findFreeCluster(fp, bpb);
    if (newCluster == 0) 
    {
        printf("Error: No free clusters available.\n");
        return;
    }

    newDir.DIR_FstClusHI = newCluster >> 16; // High-order 16 bits of cluster number
    newDir.DIR_FstClusLO = newCluster & 0xFFFF; // Low-order 16 bits of cluster number

    // Write the new directory entry to the free directory entry offset
    fseek(fp, freeEntryOffset, SEEK_SET);
    if (fwrite(&newDir, sizeof(dentry_t), 1, fp) != 1) 
    {
        printf("Error: Failed to write new directory entry.\n");
        return;
    }

    // Calculate new cluster offset
    uint32_t newClusterOffset = firstDataSector + (newCluster - 2) * clusterSize;

    // Create . and .. entries
    dentry_t dotEntry, dotDotEntry;
    memset(&dotEntry, 0, sizeof(dentry_t));
    strncpy(dotEntry.DIR_Name, ".", 2); // Name is .
    dotEntry.DIR_Attr = 0x10; // Directory attribute
    dotEntry.DIR_FstClusHI = newCluster >> 16; // High-order 16 bits of cluster number //same as current directory since it refers to it
    dotEntry.DIR_FstClusLO = newCluster & 0xFFFF; // Low-order 16 bits of cluster number //same as current directory since it refers to it

    memset(&dotDotEntry, 0, sizeof(dentry_t));
    strncpy(dotDotEntry.DIR_Name, "..", 3); // Name is ..
    dotDotEntry.DIR_Attr = 0x10; // Directory attribute
    dotDotEntry.DIR_FstClusHI = current_cluster >> 16; // High-order 16 bits of parent cluster number //same as parent directory cause .. refers to it
    dotDotEntry.DIR_FstClusLO = current_cluster & 0xFFFF; // Low-order 16 bits of parent cluster number //same as parent directory cause .. refers to it

    // Write . and .. entries to the new directory
    fseek(fp, newClusterOffset, SEEK_SET);
    if (fwrite(&dotEntry, sizeof(dentry_t), 1, fp) != 1 || fwrite(&dotDotEntry, sizeof(dentry_t), 1, fp) != 1) 
    {
        printf("Error: Failed to write . and .. entries.\n");
        return;
    }

    // Update the FAT for the new cluster
    uint32_t fatOffset = bpb->BPB_RsvdSecCnt * bpb->BPB_BytsPerSec;
    uint32_t fatEntryOffset = fatOffset + (newCluster * 4); // Each FAT entry is 4 bytes long
    uint32_t endOfChain = 0x0FFFFFFF;

    fseek(fp, fatEntryOffset, SEEK_SET);
    if (fwrite(&endOfChain, sizeof(uint32_t), 1, fp) != 1) 
    {
        printf("Error: Failed to update the FAT.\n");
        return;
    }

}


void createFile(FILE *fp, BPB_t *bpb, const char *filename)
{
    if (strlen(filename) > 11) 
    {
        printf("Error: Directory name '%s' is too long (max 11 characters).\n", filename);
        return;
    }
    
    dentry_t dentry;
    uint32_t firstDataSector = (bpb->BPB_RsvdSecCnt + bpb->BPB_NumFATs * bpb->BPB_FATSz32) * bpb->BPB_BytsPerSec;
    int clusterSize = bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;
    uint32_t currentOffset = firstDataSector + (current_cluster - 2) * clusterSize;

    fseek(fp, currentOffset, SEEK_SET);

    while (fread(&dentry, sizeof(dentry_t), 1, fp) == 1) 
    {
        if (dentry.DIR_Name[0] == '\0') 
        {
            break; // End of directory entries
        }

        // Trim trailing spaces from the file name
        char trim[12];
        int i;
        for (i = 10; i >= 0; i--) 
        {
            if (!isspace(dentry.DIR_Name[i])) 
            {
                break;
            }
        }
        strncpy(trim, dentry.DIR_Name, i + 1);
        trim[i + 1] = '\0';

        // Check if the file/directory name matches the specified `dirname`
        if (strcmp(trim, filename) == 0) 
        {
            printf("Error: A file or directory called '%s' already exists.\n", filename);
            return;
        }
    }

    // Find free directory entry
    uint32_t freeEntryOffset = findFreeDirectoryEntry(fp, currentOffset, clusterSize);
    if (freeEntryOffset == 0) 
    {
        printf("No free directory entries available in the current working directory.\n");
        return;
    }

    // Find free cluster
    uint32_t newCluster = findFreeCluster(fp, bpb);
    if (newCluster == 0) 
    {
        printf("Error: No free clusters available.\n");
        return;
    }

    // Create a new file directory entry
    dentry_t newFile;
    memset(&newFile, 0, sizeof(dentry_t));
    strncpy(newFile.DIR_Name, filename, 11); // Set the file name
    newFile.DIR_Attr = 0x20; // Set the attribute to indicate a regular file
    newFile.DIR_FstClusHI = newCluster >> 16; // Set the high-order 16 bits of the starting cluster
    newFile.DIR_FstClusLO = newCluster & 0xFFFF; // Set the low-order 16 bits of the starting cluster
    newFile.DIR_FileSize = 0; // Set the file size to 0 bytes

    // Write the new file directory entry to the free directory entry offset
    fseek(fp, freeEntryOffset, SEEK_SET);
    fwrite(&newFile, sizeof(dentry_t), 1, fp);

    // Update the FAT to mark the cluster as used
    uint32_t fatOffset = bpb->BPB_RsvdSecCnt * bpb->BPB_BytsPerSec;
    uint32_t fatEntryOffset = fatOffset + newCluster * 4;
    fseek(fp, fatEntryOffset, SEEK_SET);
    uint32_t endOfClusterChain = 0x0FFFFFFF; // End of cluster chain marker
    fwrite(&endOfClusterChain, sizeof(uint32_t), 1, fp);
}


void openFile(FILE *fp, BPB_t *bpb, const char *filename, const char *mode) {
    dentry_t dentry;
    uint32_t firstDataSector = (bpb->BPB_RsvdSecCnt + bpb->BPB_NumFATs * bpb->BPB_FATSz32) * bpb->BPB_BytsPerSec;
    uint32_t currentClust = current_cluster;
    int fileFound = 0;

    

    // Check if the filename is too long
    if (strlen(filename) > 11) {
        printf("Error: Filename '%s' is too long (max 11 characters).\n", filename);
        return;
    }

    // Check if the file is already opened
    for (int i = 0; i < 10; i++) {
        if (strcmp(openedFiles[i].fileName, filename) == 0 && strcmp(openedFiles[i].path, current_path) == 0) {
            printf("Error: File '%s' is already opened.\n", filename);
            return;
        }
    }

    // Traverse the cluster chain to find the file
    while (currentClust < 0x0FFFFFF8 && !fileFound) {
        uint32_t currentOffset = firstDataSector + (currentClust - 2) * bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;
        
        // Iterate through each dentry in the current cluster
        for (int i = 0; i < bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec; i += sizeof(dentry_t)) {
            fseek(fp, currentOffset + i, SEEK_SET);
            fread(&dentry, sizeof(dentry_t), 1, fp);
            
            // Skip directories and check if entry is a file
            if (dentry.DIR_Attr == 0x10) {
                continue;
            }

            // Copy the name from the directory entry and trim trailing spaces
            char name[12];
            strncpy(name, dentry.DIR_Name, sizeof(dentry.DIR_Name));
            name[11] = '\0';
            
            for (int j = 11; j >= 0; j--) {
                if (name[j] == ' ' || name[j] == '\0') {
                    name[j] = '\0';
                }
            }
            
            // Check if filename matches and entry is a file
            if (strcmp(name, filename) == 0 && dentry.DIR_Attr == 0x20) {
                fileFound = 1;
                break;
            }
        }
        
        if (fileFound) {
            break;
        }
        
        // Move to the next cluster in the chain
        currentClust = get_next_cluster(fp, bpb, currentClust);
    }

    // If file not found, print an error and return
    if (!fileFound) {
        printf("Error: File '%s' not found.\n", filename);
        return;
    }

    // Calculate the starting offset of the file
    uint32_t firstCluster = (dentry.DIR_FstClusHI << 16) | dentry.DIR_FstClusLO;
    uint32_t firstOffset = firstDataSector + (firstCluster - 2) * bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;

    // Find an open spot in the openedFiles array
    int index = -1;
    for (int i = 0; i < 10; i++) {
        if (openedFiles[i].fileName[0] == '\0') {
            index = i;
            break;
        }
    }

    // If no open spot found, return an error
    if (index == -1) {
        printf("Error: Maximum number of opened files reached.\n");
        return;
    }

    // Set up the opened file structure
    openedFile file;
    strncpy(file.fileName, filename, sizeof(file.fileName) - 1);
    file.fileName[sizeof(file.fileName) - 1] = '\0';
    file.flag = determineMode(mode);
    if (file.flag == 0)
    {
        printf("Incorrect mode '%s'\n", mode);
        return;
    }
    file.currentFilePosition = firstCluster;
    file.currentFilePositionOffset = firstOffset;
    file.offset = 0;
    file.index = index;
    strcpy(file.path, current_path);
    
    // Add the file to the openedFiles array
    openedFiles[index] = file;

    // Print success message
    printf("Opened '%s' with mode '%s'\n", filename, mode);
}


void closeFile(const char *filename)
{
    for (int i = 0; i < 10; i++)
    {
        if (strcmp(openedFiles[i].fileName, filename) == 0 && strcmp(openedFiles[i].path, current_path) == 0)
        {
            openedFiles[i].fileName[0] = '\0';
            openedFiles[i].flag = 0;
            openedFiles[i].index = 0;
            openedFiles[i].offset = 0;
            openedFiles[i].currentFilePosition = 0;
            openedFiles[i].currentFilePositionOffset = 0;
            printf("File '%s' is closed. \n", filename);
            return;
        }
    }
    printf("File '%s' was not found or is not open.\n", filename);
}


void listOpenedFiles() {
    printf("Index  Name       Mode       Offset     Path\n");
    for (int i = 0; i < 10; i++) {
        if (openedFiles[i].fileName[0] != '\0') 
        {
            char *mode;
            switch (openedFiles[i].flag) {
                case 1:
                    mode = "r";
                    break;
                case 2:
                    mode = "w";
                    break;
                case 3:
                    mode = "rw";
                    break;
                case 4:
                    mode = "wr";
                    break;
                default:
                    mode = "unknown";
                    break;
            }
            printf("%-5d  %-10s  %-8s  %-9d  %s\n",
                   i,  // Index
                   openedFiles[i].fileName,  // File name
                   mode,
                   openedFiles[i].offset,  // Offset
                   openedFiles[i].path);  // Path
        }
    }
}


void lseekCommand(FILE *fp, const char *filename, BPB_t *bpb, uint32_t offset) {
    int fileIndex = -1;

    // Find the opened file by filename
    for (int i = 0; i < 10; i++) {
        if (strcmp(openedFiles[i].fileName, filename) == 0 && strcmp(openedFiles[i].path, current_path) == 0) {
            fileIndex = i;
            break;
        }
    }

    // If the file is not open, print an error message
    if (fileIndex == -1) 
    {
        printf("Error: File '%s' is not open or does not exist.\n", filename);
        return;
    }

    openedFile *file = &openedFiles[fileIndex];

    int32_t totalFileSize = 0;
    uint32_t currentCluster = file->currentFilePosition;

    // Calculate the size of each cluster and add to total file size
    while (currentCluster < 0x0FFFFFF8) {
        // Calculate the size of the current cluster
        uint32_t clusterSize = bpb->BPB_BytsPerSec * bpb->BPB_SecPerClus;
        totalFileSize += clusterSize;

        // Move to the next cluster in the file chain
        currentCluster = get_next_cluster(fp, bpb, currentCluster);

        // Check if the end of the file chain is reached
        if (currentCluster == 0x0FFFFFFF) 
        {
            break;
        }
    }

    // Compare the offset with the file size
    if (offset> totalFileSize) 
    {
        printf("Error: Offset %u is larger than the size of the file.\n", offset);
    } 
    else 
    {
        // Set the file offset
        file->offset = offset;
        printf("File '%s' offset set to %u.\n", filename, offset);
    }
}


void removeFile(FILE *fp, BPB_t *bpb, const char *filename) {
    dentry_t dentry;
    uint32_t fileOffset = 0;
    uint32_t firstDataSector = (bpb->BPB_RsvdSecCnt + bpb->BPB_NumFATs * bpb->BPB_FATSz32) * bpb->BPB_BytsPerSec;
    uint32_t currentCluster = current_cluster;
    int found = 0;

    // Iterate through the clusters to find the file
    while (currentCluster < 0x0FFFFFF8) {
        uint32_t currentOffset = firstDataSector + (currentCluster - 2) * bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;

        for (int i = 0; i < bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec; i += sizeof(dentry_t)) {
            fseek(fp, currentOffset + i, SEEK_SET);
            fread(&dentry, sizeof(dentry_t), 1, fp);

            if (dentry.DIR_Name[0] == '\0') {
                break; // End of entries
            }

            // Trim trailing spaces from the file name
            char name[12];
            strncpy(name, dentry.DIR_Name, sizeof(dentry.DIR_Name));
            name[11] = '\0';

            for (int j = 11; j >= 0; j--) {
                if (name[j] == ' ' || name[j] == '\0') {
                    name[j] = '\0';
                }
            }

            // Check if the filename matches the given filename
            if (strcmp(name, filename) == 0 && dentry.DIR_Attr == 0x20) {
                fileOffset = currentOffset + i;
                found = 1;
                break;
            }
        }

        if (found) {
            break;
        }

        // Move to the next cluster in the chain
        currentCluster = get_next_cluster(fp, bpb, currentCluster);
    }

    if (fileOffset == 0) {
        printf("Error: File '%s' does not exist in the current directory.\n", filename);
        return;
    }

    // Check if the file is open
    for (int i = 0; i < 10; i++) {
        if (openedFiles[i].fileName[0] != '\0' && strcmp(openedFiles[i].fileName, filename) == 0 &&
            strcmp(openedFiles[i].path, current_path) == 0) {
            printf("Error: File '%s' is currently open.\n", filename);
            return;
        }
    }

    // Reset the directory entry
    dentry_t emptyEntry = {0}; // Create an empty directory entry
    fseek(fp, fileOffset, SEEK_SET);
    fwrite(&emptyEntry, sizeof(dentry_t), 1, fp);

    // Reclaim clusters used by the file
    uint32_t cluster = dentry.DIR_FstClusLO | (dentry.DIR_FstClusHI << 16);
    uint32_t fatOffset = bpb->BPB_RsvdSecCnt * bpb->BPB_BytsPerSec;

    while (cluster < 0x0FFFFFF8) {
        uint32_t offsetInFAT = fatOffset + cluster * 4;
        uint32_t nextCluster;

        fseek(fp, offsetInFAT, SEEK_SET);
        fread(&nextCluster, sizeof(uint32_t), 1, fp);

        // Mark the current cluster as free
        uint32_t freeCluster = 0x00000000;
        fseek(fp, offsetInFAT, SEEK_SET);
        fwrite(&freeCluster, sizeof(uint32_t), 1, fp);

        // Move to the next cluster
        cluster = nextCluster & 0x0FFFFFFF;
    }

    printf("File '%s' successfully deleted.\n", filename);
}


void removeDirectory(FILE *fp, BPB_t *bpb, const char *dirname) 
{
    dentry_t dentry;
    uint32_t fileOffset = 0;
    uint32_t firstDataSector = (bpb->BPB_RsvdSecCnt + bpb->BPB_NumFATs * bpb->BPB_FATSz32) * bpb->BPB_BytsPerSec;
    uint32_t currentCluster = current_cluster;
    int found = 0;

    // Iterate through the clusters to find the directory
    while (currentCluster < 0x0FFFFFF8) 
    {
        uint32_t currentOffset = firstDataSector + (currentCluster - 2) * bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;

        for (int i = 0; i < bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec; i += sizeof(dentry_t)) 
        {
            fseek(fp, currentOffset + i, SEEK_SET);
            fread(&dentry, sizeof(dentry_t), 1, fp);

            if (dentry.DIR_Name[0] == '\0') 
            {
                break; // End of entries
            }

            // Trim trailing spaces from the entry name
            char name[12];
            strncpy(name, dentry.DIR_Name, sizeof(dentry.DIR_Name));
            name[11] = '\0';

            for (int j = 11; j >= 0; j--) 
            {
                if (name[j] == ' ' || name[j] == '\0') {
                    name[j] = '\0';
                }
            }

            // Check if the filename matches the given directory
            if (strcmp(name, dirname) == 0 && dentry.DIR_Attr == 0x10) 
            {
                fileOffset = currentOffset + i;
                found = 1;
                break;
            }
        }

        if (found) 
        {
            break;
        }

        // Move to the next cluster in the chain
        currentCluster = get_next_cluster(fp, bpb, currentCluster);
    }

    if (!found) 
    {
        printf("No directory named '%s'\n", dirname);
        return;
    }

    // Check if the directory is empty (excluding `.` and `..`)
    uint32_t dirCluster = dentry.DIR_FstClusLO | (dentry.DIR_FstClusHI << 16);
    if (!isDirectoryEmpty(fp, bpb, dirCluster)) 
    {
        printf("Directory '%s' is not empty.\n", dirname);
        return;
    }

    // Reset the directory entry in the parent directory to mark it as deleted
    fseek(fp, fileOffset, SEEK_SET);
    memset(&dentry, 0, sizeof(dentry_t));
    dentry.DIR_Name[0] = 0xE5; // Set DIR_Name to 0xE5 to mark the entry as deleted
    fwrite(&dentry, sizeof(dentry_t), 1, fp);

    // Reset the directory entry
    dentry_t emptyEntry = {0}; // Create an empty directory entry
    fseek(fp, fileOffset, SEEK_SET);
    fwrite(&emptyEntry, sizeof(dentry_t), 1, fp);

    // Deallocate the clusters used by the directory
    deallocateClusters(fp, bpb, dirCluster);




    printf("Directory '%s' successfully deleted.\n", dirname);
}


void readFromFile(FILE *fp, const char *filename, size_t size) 
{
    // Find the opened file in the array
    int fileIndex = -1;
    for (int i = 0; i < 10; i++) 
    {
        if (strcmp(openedFiles[i].fileName, filename) == 0 && strcmp(openedFiles[i].path, current_path) == 0) {
            fileIndex = i;
            break;
        }
    }

    // If the file is not found, print an error
    if (fileIndex == -1) {
        printf("Error: File '%s' is not open or does not exist.\n", filename);
        return;
    }

    
    openedFile *file = &openedFiles[fileIndex];

    // Check if the file is opened for reading
    if (file->flag != 1 && file->flag != 3 && file->flag != 4) 
    {
        printf("Error: File '%s' is not opened for reading.\n", filename);
        return;
    }

    // Calculate the actual starting position in the file
    fseek(fp, file->currentFilePositionOffset + file->offset, SEEK_SET);

    // Allocate buffer for reading
    char *buffer = (char *)malloc(size + 1);
    if (!buffer) 
    {
        printf("Memory allocation failed.\n");
        return;
    }

    // Read the requested amount of data
    size_t bytesRead = fread(buffer, 1, size, fp);

    // Check for read errors
    if (bytesRead == 0) 
    {
        printf("Error reading from file '%s'.\n", filename);
        free(buffer);
        return;
    }

    // Null-terminate the buffer
    buffer[bytesRead] = '\0';

    // Print the data read from the file
    printf("%s\n", buffer);

    //update offset
    file->offset += bytesRead;

    // Free the buffer
    free(buffer);
}


void writeToFile(FILE *fp, const char *filename, char *string)
{
    // Find the opened file in the array
    int fileIndex = -1;
    for (int i = 0; i < 10; i++) 
    {
        if (strcmp(openedFiles[i].fileName, filename) == 0 && strcmp(openedFiles[i].path, current_path) == 0) {
            fileIndex = i;
            break;
        }
    }

    // If the file is not found or open, print an error
    if (fileIndex == -1) {
        printf("Error: File '%s' is not open or does not exist.\n", filename);
        return;
    }

    openedFile *file = &openedFiles[fileIndex];

    // Check if the file is opened for reading
    if (file->flag != 2 && file->flag != 3 && file->flag != 4) 
    {
        printf("Error: File '%s' is not opened for writing.\n", filename);
        return;
    }

    // Calculate the actual starting position in the file
    fseek(fp, file->currentFilePositionOffset + file->offset, SEEK_SET);


    size_t stringLength = strlen(string);

    size_t bytesWritten = fwrite(string, 1, stringLength, fp);

    // Update the file offset by the number of bytes written
    file->offset += bytesWritten;

    printf("Successfully wrote to file '%s'.\n", filename);
}



/*==========================================================================
                            HELPER FUNCTIONS
============================================================================*/

void readBootSector(BPB_t *bpb, FILE *fp) {
    fseek(fp, 11, SEEK_SET);
    fread(&bpb->BPB_BytsPerSec, sizeof(bpb->BPB_BytsPerSec), 1, fp);

    fseek(fp, 13, SEEK_SET);
    fread(&bpb->BPB_SecPerClus, sizeof(bpb->BPB_SecPerClus), 1, fp);

    fseek(fp, 44, SEEK_SET);
    fread(&bpb->BPB_RootClus, sizeof(bpb->BPB_RootClus), 1, fp);

    fseek(fp, 32, SEEK_SET);
    fread(&bpb->BPB_TotSec32, sizeof(bpb->BPB_TotSec32), 1, fp);

    fseek(fp, 16, SEEK_SET);
    fread(&bpb->BPB_NumFATs, sizeof(bpb->BPB_NumFATs), 1, fp);

    fseek(fp, 36, SEEK_SET);
    fread(&bpb->BPB_FATSz32, sizeof(bpb->BPB_FATSz32), 1, fp);

    fseek(fp, 14, SEEK_SET);
    fread(&bpb->BPB_RsvdSecCnt, sizeof(bpb->BPB_RsvdSecCnt), 1, fp);

}


char** Tokenization(char input[]) {
    char **command = malloc(100 * sizeof(char*)); // Allocates memory for up to 100 tokens
    int i = 0; // Index for storing tokens
    char *token;
    char *start = input; // Starting point of each token

    while (i < 100 - 1 && *start != '\0') {
        // Skip leading whitespace
        while (*start == ' ') {
            start++;
        }

        if (*start == '\0') {
            break; // End of input string
        }

        // Check if the token starts with a quote
        if (*start == '"') {
            // Find the end of the quoted string
            token = ++start; // Skip the opening quote
            while (*start != '"' && *start != '\0') {
                start++;
            }

            // If a closing quote is found, terminate the token
            if (*start == '"') {
                *start = '\0';
                start++; // Skip the closing quote
            } else {
                // No closing quote found, treat the remaining input as part of the quoted string
                start = strchr(start, '\0');
            }
        } else {
            // Tokenize by spaces
            token = start;
            while (*start != ' ' && *start != '\0') {
                start++;
            }
            // Terminate the token
            if (*start != '\0') {
                *start = '\0';
                start++;
            }
        }

        // Store the token
        command[i++] = strdup(token);
    }

    // Null-terminate the command array
    command[i] = NULL;

    // Resize the array to fit the actual number of tokens
    return realloc(command, (i + 1) * sizeof(char*));
}


void printInfo(BPB_t bpb) {
    printf("Bytes Per Sector: %" PRIu16 "\n", bpb.BPB_BytsPerSec);
    printf("Sectors per cluster : %" PRIu8 "\n", bpb.BPB_SecPerClus);
    printf("Root cluster : %" PRIu8 "\n", bpb.BPB_RootClus);
    printf("total # of clusters in data region : %" PRIu8 "\n", bpb.BPB_TotSec32);
    printf("# of entries in one fat : %" PRIu8 "\n", bpb.BPB_NumFATs);
    uint32_t image_size = bpb.BPB_TotSec32 * bpb.BPB_BytsPerSec;
    printf("Size of image (in bytes) : %" PRIu32 "\n", image_size);
}


uint32_t findFreeCluster(FILE *fp, BPB_t *bpb)
{
    //calc fat offset
    uint32_t fatOffset = bpb->BPB_RsvdSecCnt * bpb->BPB_BytsPerSec;

    uint32_t numCluster = bpb->BPB_TotSec32 / bpb->BPB_SecPerClus;
    //total number of clusters in system

    //starting at cluster 2 cause spec says its the first usable one
    for (uint32_t cluster = 2; cluster <= numCluster + 1; cluster++) 
    {
        // Calculate the offset in the FAT for the given cluster
        uint32_t offset = fatOffset + cluster * 4; // Each entry in the FAT is 4 bytes long

        // Seek to the offset and read the cluster status
        uint32_t clusterStatus;
        fseek(fp, offset, SEEK_SET);
        fread(&clusterStatus, sizeof(uint32_t), 1, fp);

        // Check if the cluster is free (0x00000000)
        if (clusterStatus == 0x00000000) 
        {
            // Found a free cluster, return its number
            return cluster;
        }
    }

     // No free clusters found
    return 0;

}


uint32_t get_next_cluster(FILE *imgFile, BPB_t *bpb, uint32_t current_cluster_number) 
{
    // Calculate the offset in the FAT for the given cluster
    uint32_t fat_offset = bpb->BPB_RsvdSecCnt * bpb->BPB_BytsPerSec;
    uint32_t offset_in_fat = fat_offset + current_cluster_number * 4; // Each entry in the FAT is 4 bytes long

    // Seek to the offset in the FAT and read the next cluster number
    fseek(imgFile, offset_in_fat, SEEK_SET);
    uint32_t next_cluster_number;
    fread(&next_cluster_number, sizeof(uint32_t), 1, imgFile);

    // Mask out the upper bits of the cluster number, as they may contain reserved or end-of-chain markers
    next_cluster_number &= 0x0FFFFFFF;

    // Return the next cluster number in the chain
    return next_cluster_number;
}


uint32_t findFreeDirectoryEntry(FILE *fp, uint32_t clusterOffset, int clusterSize) 
{
    dentry_t dentry;
    uint32_t entryOffset = clusterOffset;

    // look through the directory entries in the current cluster
    while (entryOffset < clusterOffset + clusterSize) 
    {
        // Seek and read the entry
        fseek(fp, entryOffset, SEEK_SET);
        fread(&dentry, sizeof(dentry_t), 1, fp);

        // Check if the directory entry is free
        if (dentry.DIR_Name[0] == 0x00 || dentry.DIR_Name[0] == 0xE5)
         {
            // Entry is free cause its either empty or deleted 
            return entryOffset; // Return the offset of the free entry
        }

        // Move to the next entry
        entryOffset += sizeof(dentry_t);
    }

    // No free entry found in this cluster
    return 0;
}


// Helper function to check if a directory is empty (excluding `.` and `..`)
int isDirectoryEmpty(FILE *fp, BPB_t *bpb, uint32_t dirCluster) 
{
    uint32_t firstDataSector = (bpb->BPB_RsvdSecCnt + bpb->BPB_NumFATs * bpb->BPB_FATSz32) * bpb->BPB_BytsPerSec;
    dentry_t dentry;
    while (dirCluster < 0x0FFFFFF8) 
    {
        uint32_t dirOffset = firstDataSector + (dirCluster - 2) * bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec;

        for (uint32_t offset = dirOffset; offset < dirOffset + bpb->BPB_SecPerClus * bpb->BPB_BytsPerSec; offset += sizeof(dentry_t)) 
        {
            fseek(fp, offset, SEEK_SET);
            fread(&dentry, sizeof(dentry_t), 1, fp);

            if (dentry.DIR_Name[0] == '\0') 
            {
                continue; // End of entries
            }

            char name[12];
            strncpy(name, dentry.DIR_Name, sizeof(dentry.DIR_Name));
            name[11] = '\0';

            for (int j = 11; j >= 0; j--) 
            {
                if (name[j] == ' ' || name[j] == '\0') 
                {
                    name[j] = '\0';
                }
            }


            // Skip `.` and `..`
            if (strcmp(name, ".") == 0 || strcmp(name, "..") == 0) 
            {
                continue;
            }

            // if non empty directory cant deleted
            if (dentry.DIR_Name[0] != 0xE5) 
            {
                return 0; // Directory is not empty
            }
        }

        // Move to the next cluster in the chain
        dirCluster = get_next_cluster(fp, bpb, dirCluster);
    }
    return 1; // Directory is empty
}

// Helper function to deallocate clusters used by a directory
void deallocateClusters(FILE *fp, BPB_t *bpb, uint32_t dirCluster) 
{
    uint32_t fatOffset = bpb->BPB_RsvdSecCnt * bpb->BPB_BytsPerSec;

    while (dirCluster < 0x0FFFFFF8) 
    {
        uint32_t offsetInFAT = fatOffset + dirCluster * 4;
        uint32_t nextCluster;

        fseek(fp, offsetInFAT, SEEK_SET);
        fread(&nextCluster, sizeof(uint32_t), 1, fp);

        // Mark the current cluster as free
        uint32_t freeCluster = 0x00000000;
        fseek(fp, offsetInFAT, SEEK_SET);
        fwrite(&freeCluster, sizeof(uint32_t), 1, fp);

        // Move to the next cluster
        dirCluster = nextCluster & 0x0FFFFFFF;
    }
}



void addToPath(char *dir) //adds and removes from path when cd is used
{
    if (dir == NULL)
    {
        return;
    }
    else if(strcmp(dir, "..") == 0) {
                char *last = strrchr(current_path, '/');
                if(last != NULL) {
                        *last = '\0';
                }
        } else if(strcmp(dir, ".") != 0) {
                strcat(current_path, "/");
                strcat(current_path, dir);
        }
}