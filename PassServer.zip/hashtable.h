#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <vector>
#include <list>
#include <string>     // string.c_str(), string();
#include <algorithm>  // find
#include <functional> // hash
#include <iostream>   // cout, cerr
#include <fstream>    // ifstream and ofstream
#include <string.h>   // strcpy, strtok, 

using namespace std;

// max_prime is used by the helpful functions provided to you.
static const unsigned int max_prime = 1301081;
 
// SeparateChaining Hash table class
namespace cop4530 {
   template <typename K, typename V>
      class HashTable
      {
         public:
            explicit HashTable(size_t size = 101); 
	      size_t size() const; 

         ~HashTable(); 
         bool contains(const K & x); 
         bool match(const pair<K, V> &kv) const; 
         bool insert(const pair<K, V> &kv); 
         bool insert(pair<K, V> && kv); 
         bool remove(const K & k); 
         void clear();  
         bool load(const char * filename);  
         void dump();  
         bool write_to_file(const char *filename); 
   

         private:
            size_t currentSize;
            vector<list<pair<K, V>>> ht;  //Vector of lists called ht = HashTable
         
         void makeEmpty(); 
         void rehash(); 
         size_t myhash(const K & x); 
         unsigned long prime_below(unsigned long n);  
         void setPrimes(vector<unsigned long>&);  
      };

} // end of namespace cop4530

#include "hashtable.hpp"

#endif
