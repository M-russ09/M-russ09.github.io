# To Run:

Please ensure to have G++ compiler installed on your operating system. The G++ compiler is typically native to Linux operating systems, however, if you have Windows/Mac operating systems you will have to install to run. 

[G++ Compiler for Windows](https://www.msys2.org)
Once the installation is completed, make sure to ==add your MinGW-w64 `bin` folder to the Windows `PATH` environment variable==

For Mac, if you have XCode installed, the C++ compiler (clang) should already be native by running g++.

Once a G++ compiler is installed, simply *make* and run *./userpass*.
The zip file comes with an example list of users (*sample_users.txt*), which can be used to showcase the *-l* option. 





