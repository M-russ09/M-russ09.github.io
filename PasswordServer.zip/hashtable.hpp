#include "hashtable.h"

using namespace cop4530;

//K = Keys V = Values in the HashTable

//=============================
//      PUBLIC FUNCTIONS
//=============================

/* HashTable Constructor:
Set the table size by passing in the size (if one
is provided). Pass the prime_below size into the
resize function to create the ht and set its size.
Set the currentSize (content of the hash table
to 0)*/
template <typename K, typename V>
HashTable<K, V>::HashTable(size_t size) 
{
   size_t tableSize = prime_below(size);
   ht.resize(tableSize);
   currentSize = 0;
}

template <typename K, typename V>
size_t HashTable<K, V>::size() const
{
   return currentSize;
}

/* HashTable Destructor:
A ranged based auto for loop that
loops through the vector and clears
each list in the vector
*/
template <typename K, typename V>
HashTable<K, V>::~HashTable()
{
   for (auto& list: ht) 
      list.clear();
}

/* HashTable Cointains:
Start by locating the group that the hashed
key lives in. Using a ranged based for loop,
loop through those groups and check if the 
passed in argument matches a key in one of
the pairs of the group */
template <typename K, typename V>
bool HashTable<K, V>::contains(const K& x)
{
   size_t group = hash<K>{}(x) % ht.size();
   for (const auto& i : ht[group]) {
      if (i.first == x) {
         return true;
      }
   }
   return false;
}

/* HashTable Match: 
Start by locating the group that the pair
lives in. Using a ranged based for loop,
loop through the groups and check if the pair
lives in the group, yes return true, no return false
*/
template <typename K, typename V>
bool HashTable<K, V>::match(const pair<K, V> & kv) const
{
   size_t group = hash<K>{}(kv.first) % ht.size();
   for (const auto& i : ht[group]) {
      if (i == kv) {
         return true;
      }
   }
   return false;
}

/*  HashTable Insert:
Check to see if the pair has already been inserted.
Locate the group to insert the pair. Push back
the pair and increase the currentSize. If the 
currentSize is greater than the hash table size
rehash.
*/
template <typename K, typename V>
bool HashTable<K, V>::insert(const pair<K, V> &kv)
{
   if (contains(kv.first))
      return false;

   size_t group = hash<K>{}(kv.first) % ht.size();

   ht[group].push_back(kv);
   ++currentSize;

   if (currentSize > ht.size()) {
      rehash();
   }

   return true;
}

//Move Version of Insert
template <typename K, typename V>
bool HashTable<K, V>::insert(pair<K, V> && kv)
{
   if (contains(kv.first))
      return false;

   size_t group = hash<K>{}(kv.first) % ht.size();

   ht[group].push_back(kv);
   ++currentSize;

   if (currentSize > ht.size()) {
      rehash();
   }

   return true;
}

/*  HashTable Remove:
Locate the list the passed in key is located in.
Using a for loop, looping through the vector beginning
to end, if the first pair value matches the passed in
value, erase it and subtract the current size by 1.
Then return true within that if, otherwise return false.
*/
template <typename K, typename V>
bool HashTable<K, V>::remove(const K& k)
{
   size_t group = hash<K>{}(k) % ht.size();

   for (auto i = ht[group].begin(); i != ht[group].end(); i++) {
      if (i->first == k) {
         ht[group].erase(i);
         --currentSize;
         return true;
      }
   }
   return false;
}

template <typename K, typename V>
void HashTable<K, V>::clear()
{
   makeEmpty();
}

/* HashTable Load:
Using the fstream library we created our infile
object. Next check to see if the file is available  
to open. While available, find the space character on
the line and set the user and pass strings to the 
file contents using the substr and space value.
Finally, make the pair and insert the pair into
the hash table.
*/
template <typename K, typename V>
bool HashTable<K, V>::load(const char *filename)
{
   ifstream infile(filename);
   string line, user, pass;

   if (!infile.is_open()) {
      cout << "Error: cannot open file \"" << filename << "\"" << endl;
      return false;
   }
   
   while (getline(infile, line)) {
      size_t space = line.find(" ");

      user = line.substr(0, space);
      pass = line.substr(space + 1);

      pair<string, string> acc = make_pair(user, pass);
      insert(acc);
   } 
   return true;
}

/* HashTable Dump:
To empty the entirety of the hash table we need
2 for loops. One that goes through the vector, the
other goes through the lists. In the nested loop,
we print the pair and increase the counter. If the 
counter is greater than 0 (one has been printed), 
print the '|' to separate the pairs in that list.
Then it goes to the outer loop and prints a endl
as long as the hash table group is not empty and then 
resets the count.
*/
template <typename K, typename V>
void HashTable<K, V>::dump()
{
   int count = 0;
   for (size_t i = 0; i < ht.size(); ++i) {
      count = 0;
      for (const auto& j : ht[i]) {
         if (count > 0) {
            cout << " | ";
         }
         cout << j.first << ", " <<  j.second;
         count++;
      }
      if (!(ht[i].empty()))
         cout << endl;
   }
}

/* HashTable Write-to-file:
Using the fstream library we created our outfile
object. Next check to see if the file is available  
to open. If it is not return false, else continue.
2 for loops will go through the lists inside the 
vectors and print the contents of the hash table
to the outfile, one on each line.
*/
template <typename K, typename V>
bool HashTable<K, V>::write_to_file(const char *filename)
{  
   std::ofstream outfile(filename);
   if (!outfile.is_open()) {
      return false;
   }

   for (const auto& i : ht) {
      for (const auto& j : i) {
         outfile << j.first << " " << j.second << "\n";
      }
   }
   outfile.close();
   return true;
}



//==============================
//     PRIVATE FUNCTIONS
//==============================

// returns largest prime number <= n or zero if input is too large
// This is likely to be more efficient than prime_above(), because
// it only needs a vector of size n
template <typename K, typename V>
unsigned long HashTable<K, V>::prime_below (unsigned long n)
{
   if (n > max_prime)
   {
      cout << "** input too large for prime_below()\n";
      return 0;
   }
   if (n == max_prime)
   {
      return max_prime;
   }
   if (n <= 1)
   {
      cout << "** input too small \n";
      return 0;
   }

   // now: 2 <= n < max_prime
   vector <unsigned long> v (n+1);
   setPrimes(v);
   while (n > 2)
   {
      if (v[n] == 1)
         return n;
      --n;
   }

   return 2;
}


//Sets all prime number indexes to 1. Called by method prime_below(n) 
template <typename K, typename V>
void HashTable<K, V>::setPrimes(std::vector<unsigned long>& vprimes)
{
   int i = 0;
   int j = 0;

   vprimes[0] = 0;
   vprimes[1] = 0;
   int n = vprimes.capacity();

   for (i = 2; i < n; ++i)
      vprimes[i] = 1;

   for( i = 2; i*i < n; ++i)
   {
      if (vprimes[i] == 1)
         for(j = i + i ; j < n; j += i)
            vprimes[j] = 0;
   }
}


template <typename K, typename V>
void HashTable<K, V>:: makeEmpty()
{
   for (auto& i : ht) 
      i.clear();

   currentSize = 0;
}

template <typename K, typename V>
void HashTable<K, V>::rehash()
{
   vector<list<pair<K, V>>> oldT = ht;

   ht.resize(prime_below(2 * ht.size()));
   for (auto& group : ht) 
      group.clear();

   currentSize = 0;
   for (auto& group : oldT) {
      for (auto& i : group) {
         insert(std::move(i));
      }
   }
}

template <typename K, typename V>
size_t HashTable<K, V>::myhash(const K & x)
{
   size_t hVal = hash<K>{}(x);
   return hVal % ht.size();
}


