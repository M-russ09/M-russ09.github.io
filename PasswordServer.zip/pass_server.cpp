#include <vector>
#include <list>
#include <string>     // string.c_str(), string();
#include <algorithm>  // std::find
#include <functional> // std::hash
#include <iostream>   // std::cout, std::cerr
#include <fstream>    // ifstream and ofstream
#include <string.h>   // strcpy, strtok, 
#include <unistd.h>   // crypt()
#include <stdlib.h>   

#include "hashtable.h"
#include "pass_server.h"

using namespace std;
using namespace cop4530;

//=============================
//      PUBLIC FUNCTIONS
//=============================

 
template <typename K, typename V>
size_t PassServer<K,V>::size()
{
   return HashTable<K,V>::size();
}

/* PassServer Constructor:
Calls the HashTable constructor of the 
passed in size. 
*/
template <typename K, typename V>
PassServer<K,V>::PassServer(size_t size) : HashTable<K,V>::HashTable(size)
{}


template <typename K, typename V>
PassServer<K, V>::~PassServer()
{
   HashTable<K, V>::clear();
}

/* PassServer Load:
Same as the HashTable Load implementation, 
except this inserts a new user instead of
inserting directly into the hash table
*/
template <typename K, typename V>
bool PassServer<K, V>:: load(const char *filename)
{
   ifstream infile(filename);
   string line, user, pass;

   if (!infile.is_open()) {
      cout << "Error: cannot open file \"" << filename << "\"" << endl;
      return false;
   }
   
   while (getline(infile, line)) {
      size_t space = line.find(" ");

      user = line.substr(0, space);
      pass = line.substr(space + 1);

      pair<string, string> acc = make_pair(user, pass);
      addUser(acc);
   } 
   return true;
}

/* PassServer addUser:
Takes in a pair (user and pass).
Using the encrypt function, we encrypt the
password that was passed in. Then call the 
HashTable function insert with the new encrypted
password. This will add the user and encrypted 
password to the hash table and return with a
bool value. True = success insert. False = fail.
*/
template <typename K, typename V>
bool PassServer<K, V>:: addUser(pair<string, string> &kv)
{
   
   string encPass = encrypt(kv.second);
   return HashTable<K, V>::insert(make_pair(kv.first, encPass));
}

//Move Version of addUser
template <typename K, typename V>
bool PassServer<K, V>:: addUser(pair<string, string> &&kv)
{
   string encPass = encrypt(kv.second);
   return HashTable<K, V>::insert(make_pair(kv.first, encPass));
}

template <typename K, typename V>
bool PassServer<K, V>:: removeUser(const string &k)
{
   return HashTable<K, V>::remove(k);
}

/* PassServer changePassword:
 Check if the user is in the hash table.
 If not, return false. If the user is in the hash table,
 check if the old password is correct by using match. If not, return
 false again. Lastly, remove the old user and insert a new 
 one with the same username and the new password.
 */
template <typename K, typename V>
bool PassServer<K, V>:: changePassword(const pair<string, string> &p, const string &newPass)
{
   if (!(HashTable<K,V>::contains(p.first))) {
      return false;
   }

   string encTemp = encrypt(p.second);
   
   if (!(HashTable<K,V>::match(make_pair(p.first, encTemp)))) {
      return false;
   }

   removeUser(p.first);
   addUser(make_pair(p.first, newPass));
   return true;
}

/* PassServer find:
Using HashTable contain, if the function returns
true using the passed in user, return true
otherwise return false.
*/
template <typename K, typename V>
bool PassServer<K, V>:: find(const string &user)
{
      if (HashTable<K,V>::contains(user)) {
         return true;
      } else {
         return false;
   }
}

template <typename K, typename V>
void PassServer<K, V>:: dump()
{
   HashTable<K, V>::dump();
}

template <typename K, typename V>
bool PassServer<K, V>:: write_to_file(const char *filename)
{
  return HashTable<K, V>::write_to_file(filename);
}

//===================================
//       PRIVATE FUNCTION
//===================================

template <typename K, typename V>
string PassServer<K, V>:: encrypt(const string &str)
{
   char salt[] = "$1$########";
   
   char *enc = new char[100];
   strcpy(enc, crypt(str.c_str(), salt));
   
   string encStr(enc);
   encStr.erase(0, 12);
   delete[] enc;
   return encStr;
}


/* XXX: Please keep this line at the very end */
template class PassServer<string, string>;
