#include <iostream>
#include <string>

#include "hashtable.h"
#include "pass_server.h"

using namespace std;

void menu()
{
   cout << "\n\n";
   cout << "l - Load From File" << endl;
   cout << "a - Add User" << endl;
   cout << "r - Remove User" << endl;
   cout << "c - Change User Password" << endl;
   cout << "f - Find User" << endl;
   cout << "d - Dump HashTable" << endl;
   cout << "s - HashTable Size" << endl; //Y
   cout << "w - Write to Password File" << endl;
   cout << "x - Exit program" << endl; //Y
   cout << "\nEnter choice : ";
}

int main()
{
   bool toexit = false;
   string line;
   char menuInput;
   bool check = false;

   PassServer<string, string> ps{};
   pair<string, string> account;

   
   while (menuInput != 'x' && menuInput != 'X') {
      menu();
      cin >> menuInput;
      switch(menuInput) {
         case 'l': case 'L':
         {
            string filename;
      
            cout <<"\nPlease enter a filename: ";
            cin >> filename;
            check = ps.load(filename.c_str());

            if (check) {
               cout << "\n\tSuccess loading file."  << endl;
            } else {
               cout << "\n\tFail to load file." << endl;
            }
            break;
         }
         
         case 'a': case 'A':
         {
            string user, pass;
            cout << "\nPlease enter a username: ";
            cin >> user;
            cout << "\nPlease enter a password: ";
            cin >> pass;
            
            account = make_pair(user, pass);
            check = ps.addUser(account);
            if (check) {
               cout << "\n\tSuccess adding " << user << endl;
            } else {
               cout << "\n\tFailure adding " << user << endl;
            }
            
            break;
         }
         
         case 'r': case 'R':
         {
            string user;

            cout << "\nPlease enter a username: ";
            cin >> user;
            check = ps.removeUser(user);
           if (check) {
               cout << "\n\tSuccess removing " << user << endl;
            } else {
               cout << "\n\tFailure removing " << user << endl;
            }
            break;
         }
         
         case 'c': case 'C':
         {
            string user, oldPass, newPass;
            cout << "\nPlease enter a username: ";
            cin >> user;
            cout << "\nPlease enter the current password: ";
            cin >> oldPass;
            cout << "\nPlease enter in the new password: ";
            cin >> newPass;


            account = make_pair(user, oldPass);
            check = ps.changePassword(account, newPass);
            if (check) {
               cout << "\n\tSuccess changing " << user << endl;
            } else {
               cout << "\n\tFailure changing " << user << endl;
            }

            break;
         }
         
         case 'f': case 'F':
         {
            string user;

            cout << "\nPlease enter a username: ";
            cin >> user;
            check = ps.find(user);
            if (check) {
               cout << "\n\tSuccess finding " << user << endl;
            } else {
               cout << "\n\tFailure finding " << user << endl;
            }
            break;
         }

         case 'd': case 'D':
         {
            cout << "\n----- Beginning Dump -----" << endl;
            ps.dump();
            cout << "\n----- End -----" << endl;
            break;
         }

         case 's': case 'S':
         {
            cout << "\n\tThe current size is " << ps.size() << endl;
            break;
         }

         case 'w': case 'W':
         {
            string filename;

            cout << "\nPlease enter a filename: ";
            cin >> filename;
            check = ps.write_to_file(filename.c_str());
            if (check) {
               cout << "\n\tSuccess writing to file " << filename << endl;
            } else {
               cout << "\n\tFailed writing to " << filename << endl;
            }
            break;
         }

         case 'x': case 'X':
         {
            cout << "\n\tExiting..." << endl;
            return 0;
         }

         default:
         cout << "\n\tInvalid Selection." << endl;
      }
   }

   return 0;
}
